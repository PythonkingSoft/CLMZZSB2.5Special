def 提取邮箱(欲要处理的文本文件路径,处理后的文本文件保存位置,开始前是否清空文件,是否打印分离密正_list):
    import re
    if 开始前是否清空文件==True:
        清空文件 = open(处理后的文本文件保存位置,"w",encoding="utf-8")
        清空文件过程 = 清空文件.write(" ")
        清空文件.close()
        print("提取邮箱--文件清空完成!")
    elif 开始前是否清空文件==False:
        print("用户未要求清空文件!")
    读取 = open(欲要处理的文本文件路径,"r",encoding="utf-8")
    读取结果 = 读取.read()
    读取.close()
    分割结果 = 读取结果.split("\n")
    分离密正_list = []
    正则 = "(.*?):"
    for i in range(len(分割结果)):
        查找 = re.findall(正则, 分割结果[i - 1])
        分离密正_list.append(查找)
    if 是否打印分离密正_list==True:
        print(分离密正_list)
    elif 是否打印分离密正_list==False:
        pass
    with open(处理后的文本文件保存位置, "a", encoding="utf-8") as 保存文本:
        for 元素 in 分离密正_list:
            保存文本.write(str(元素) + "\n")
def 统计邮箱_密正的个数(欲要统计的文本文件路径):
    统计 = open(欲要统计的文本文件路径,"r",encoding="utf-8")
    统计结果 = 统计.read()
    统计.close()
    分离换行 = 统计结果.split("\n")
    print("一共有",len(分离换行),"个邮箱_密正")
def 提取密正(欲要提取密正文件的路径,处理后的文本文件保存位置,是否清空文件):
    if 是否清空文件==True:
        清空文件 = open(处理后的文本文件保存位置,"w",encoding="utf-8")
        清空文件过程 = 清空文件.write(" ")
        清空文件.close()
        print("提取密正--文件清空完成!")
    elif 是否清空文件==False:
        print("用户未要求清空文件!")
    打开文件 = open(欲要提取密正文件的路径,"r",encoding="utf-8")
    读取结果 = 打开文件.read()
    打开文件.close()
    分割换行符 = 读取结果.split("\n")
    for i in range(len(分割换行符)):
        分割密正 = 分割换行符[i-1].split(":")
        #print(分割密正[-1])
        #保存文件 = open(处理后的文本文件保存位置,"a",encoding="utf-8")
        #保存文件.write(分割密正[-1]+"\n")
        #保存文件.close()
        with open(处理后的文本文件保存位置,"a",encoding="utf-8") as 保存文件:
            for 元素 in 分割密正:
                保存文件.write(元素+"\n")
    print("密正提取完成!")
def 提取指定品牌邮箱_含密正(欲要提前的文件路径,欲要提取的品牌_无需加上艾特,处理后的文本文件保存位置,是否清空文件,是否打印指定品牌邮箱_含密正):
    if 是否清空文件==True:
        清空文件 = open(处理后的文本文件保存位置,"w",encoding="utf-8")
        清空文件过程 = 清空文件.write(" ")
        清空文件.close()
        print("提取指定品牌邮箱_含密正--文件清空完成!")
    elif 是否清空文件==False:
        print("用户未要求清空文件!")
    打开文件 = open(欲要提前的文件路径,"r",encoding="utf-8")
    读取结果 = 打开文件.read()
    打开文件.close()
    分割换行符 = 读取结果.split("\n")
    指定品牌邮箱和密正 = []
    for i in range(len(分割换行符)):
        if "@"+欲要提取的品牌_无需加上艾特 in 分割换行符[i-1]:
            指定品牌邮箱和密正.append(分割换行符[i-1])
        elif "@"+欲要提取的品牌_无需加上艾特 not in 分割换行符[i-1]:
            pass
    if 是否打印指定品牌邮箱_含密正==True:
        print(指定品牌邮箱和密正)
    elif 是否打印指定品牌邮箱_含密正==False:
        pass
    for j in range(len(指定品牌邮箱和密正)):
        保存文件 = open(处理后的文本文件保存位置,"a",encoding="utf-8")
        保存文件.write(指定品牌邮箱和密正[j]+"\n")
        保存文件.close()
def 帮助_输出():
    print("提取邮箱(欲要处理的文本文件路径,处理后的文本文件保存位置,开始前是否清空文件,是否打印分离密正_list)\n\n统计邮箱_密正的个数(欲要统计的文本文件路径)\n\n提取密正(欲要提取密正文件的路径,处理后的文本文件保存位置,是否清空文件)\n\n提取指定品牌邮箱_含密正(欲要提前的文件路径,欲要提取的品牌_无需加上艾特,处理后的文本文件保存位置,是否清空文件,是否打印指定品牌邮箱_含密正)\n\n帮助_输出()")
def 提取指定品牌邮箱_不含密正(欲要提取的邮箱文件路径,处理后的文本文件保存位置,是否清空文件,提取什么邮箱的品牌_不含艾特,是否打印处理后的结果,是否输出处理进度):
    提取纯邮箱_纯 =[]
    if 是否清空文件==True:
        清空文件 = open(处理后的文本文件保存位置,"w",encoding="utf-8")
        清空文件过程 = 清空文件.write(" ")
        清空文件.close()
        print("提取指定品牌邮箱--文件清空完成!")
    elif 是否清空文件==False:
        print("用户未要求清空文件!")
    打开文件 = open(欲要提取的邮箱文件路径,"r",encoding="utf-8")
    读取结果 = 打开文件.read()
    打开文件.close()
    分割换行符 = 读取结果.split("\n")
    print(分割换行符)
    for i in range(len(分割换行符)):
        提取纯邮箱 = 分割换行符[i-1].split(":")
        #print(提取纯邮箱)
        提取纯邮箱_纯.append(提取纯邮箱[0])
    #print(提取纯邮箱_纯)
    for j in range(len(提取纯邮箱_纯)):
        if 提取什么邮箱的品牌_不含艾特 in 提取纯邮箱_纯[j-1]:
            #print(提取纯邮箱_纯[j-1])
            if 是否打印处理后的结果==True:
                print(提取纯邮箱_纯[j-1])
            elif 是否打印处理后的结果==False:
                pass
            if 是否输出处理进度==True:
                print("处理进度:",j,"/",len(提取纯邮箱_纯))
            elif 是否打印处理后的结果==False:
                pass
            保存文件 = open(处理后的文本文件保存位置,"a",encoding="utf-8")
            保存文件.write(提取纯邮箱_纯[j-1]+"\n")
            保存文件.close()
    print("处理进度:",len(提取纯邮箱_纯),"/",len(提取纯邮箱_纯))
    print("已完成!")
